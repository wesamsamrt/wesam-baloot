import type {Metadata} from 'next';
import './globals.css';
export const metadata:Metadata={title:'WESAM | حاسبة بلوت',description:'حاسبة بلوت برعاية WESAM. سجّل نقاط لنا ولهم، تابع الجولات، واحفظ الصكة على جهازك.'};
export default function RootLayout({children}:{children:React.ReactNode}){return <html lang="ar" dir="rtl"><body>{children}</body></html>;}
