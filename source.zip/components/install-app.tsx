'use client';
import {useEffect,useRef,useState} from 'react';
import {Download,Check} from 'lucide-react';
import {Dialog,DialogContent,DialogTitle,DialogDescription,DialogClose} from '@/components/ui/dialog';
type InstallEvent=Event & {prompt:()=>Promise<void>;userChoice:Promise<{outcome:'accepted'|'dismissed'}>};
export default function InstallApp(){
 const pending=useRef<InstallEvent|null>(null);
 const [installed,setInstalled]=useState(false),[busy,setBusy]=useState(false),[help,setHelp]=useState(false),[ios,setIos]=useState(false);
 useEffect(()=>{
  const media=window.matchMedia('(display-mode: standalone)');
  const sync=()=>setInstalled(media.matches||Boolean((navigator as Navigator & {standalone?:boolean}).standalone));sync();
  setIos(/iPad|iPhone|iPod/.test(navigator.userAgent)||(navigator.platform==='MacIntel'&&navigator.maxTouchPoints>1));
  const capture=(e:Event)=>{e.preventDefault();pending.current=e as InstallEvent;};
  const done=()=>{pending.current=null;setInstalled(true);setHelp(false);};
  window.addEventListener('beforeinstallprompt',capture);window.addEventListener('appinstalled',done);media.addEventListener('change',sync);
  if('serviceWorker' in navigator&&document.querySelector('link[rel="manifest"]')){
   void navigator.serviceWorker.register(new URL('./sw.js',document.baseURI),{scope:'./'}).catch(()=>{});
  }
  return()=>{window.removeEventListener('beforeinstallprompt',capture);window.removeEventListener('appinstalled',done);media.removeEventListener('change',sync);};
 },[]);
 async function install(){
  if(!pending.current){setHelp(true);return;}
  const event=pending.current;pending.current=null;setBusy(true);
  try{await event.prompt();const choice=await event.userChoice;if(choice.outcome==='accepted')setInstalled(true);}catch{setHelp(true);}finally{setBusy(false);}
 }
 return <><button className="install-button" onClick={install} disabled={busy||installed}>{installed?<Check size={17}/>:<Download size={17}/>}<span>{installed?'تم التثبيت':busy?'جارٍ فتح التثبيت…':'ثبّت التطبيق'}</span></button><Dialog open={help} onOpenChange={setHelp}><DialogContent dir="rtl" showCloseButton={false}><DialogTitle>ثبّت حاسبة WESAM</DialogTitle><DialogDescription>{ios?'افتح الحاسبة في Safari، ثم اضغط «مشاركة» واختر «إضافة إلى الشاشة الرئيسية»، وبعدها «إضافة».':'إذا ظهر خيار «تثبيت التطبيق» في قائمة المتصفح، اختره وأكّد التثبيت. إذا لم يظهر، افتح الرابط في Chrome أو Edge خارج المتصفح الداخلي، ثم جرّب مجددًا.'}</DialogDescription><p className="install-hint">تفتح من أيقونتها على جهازك، وتحفظ الصكة عليه.</p><DialogClose className="primary">فهمت</DialogClose></DialogContent></Dialog></>;
}
