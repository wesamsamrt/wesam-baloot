import {readFileSync} from 'node:fs';
import vm from 'node:vm';
import assert from 'node:assert/strict';
const scope='https://example.test/wesam-baloot/';
const listeners={},storage=new Map();let added=[];let online=true;
const cache={addAll:async urls=>{added=urls;urls.forEach(url=>storage.set(url,new Response('offline')));},put:async(k,v)=>storage.set(k,v)};
vm.runInNewContext(readFileSync('public/sw.js','utf8'),{URL,Response,self:{registration:{scope},location:{origin:'https://example.test'},addEventListener:(t,fn)=>listeners[t]=fn,skipWaiting:async()=>{},clients:{claim:async()=>{}}},caches:{open:async()=>cache,match:async r=>storage.get(typeof r==='string'?r:r.url),keys:async()=>[],delete:async()=>true},fetch:async()=>{if(!online)throw Error('offline');return new Response('latest');}});
let work;listeners.install({waitUntil:p=>work=p});await work;
assert.equal(added.length,5);assert(added.every(url=>url.startsWith(scope)));
let response;const request={url:scope,method:'GET',mode:'navigate'};
listeners.fetch({request,respondWith:p=>response=p});assert.equal(await (await response).text(),'latest');
online=false;listeners.fetch({request,respondWith:p=>response=p});assert.equal(await (await response).clone().text(),'latest');
let intercepted=false;listeners.fetch({request:{url:'https://example.test/other/',method:'GET',mode:'navigate'},respondWith:()=>intercepted=true});assert.equal(intercepted,false);
const manifest=JSON.parse(readFileSync('public/manifest.webmanifest','utf8'));assert.equal(manifest.scope,'./');assert.equal(manifest.display,'standalone');for(const icon of manifest.icons){const png=readFileSync('public/'+icon.src);const n=Number(icon.sizes.split('x')[0]);assert.equal(png.readUInt32BE(16),n);assert.equal(png.readUInt32BE(20),n);}
console.log('PASS: offline fallback, fresh navigation cache, scope isolation, manifest and icon sizes');
