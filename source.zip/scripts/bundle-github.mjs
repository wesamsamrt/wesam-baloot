import fs from 'node:fs';
import path from 'node:path';
const root='github-dist';
let html=fs.readFileSync(path.join(root,'index.html'),'utf8');
html=html.replace(/<script type="module"[^>]*src="([^"]+)"[^>]*><\/script>/g,(_,src)=>'<script type="module">'+fs.readFileSync(path.join(root,src),'utf8').replace(/<\/script/gi,'<\\/script')+'</script>');
html=html.replace(/<link rel="stylesheet"[^>]*href="([^"]+)"[^>]*>/g,(_,src)=>'<style>'+fs.readFileSync(path.join(root,src),'utf8')+'</style>');
fs.writeFileSync(path.join(root,'index.html'),html);
if(/(?:src|href)="\.\/assets\//.test(html))throw new Error('Unbundled assets remain');
console.log('Standalone GitHub Pages HTML ready');
